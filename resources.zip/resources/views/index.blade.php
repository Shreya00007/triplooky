@extends("front.layout.header")
@section("title","Home")
@section("content")
 <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

     
      <ol class="carousel-indicators" id="hero-carousel-indicators">
        
        @foreach($banner as $key => $list)
        <li data-bs-target="#heroCarousel" data-bs-slide-to="{{$key}}" class="{{$key == 0 ? 'active' : '' }}" aria-current="true"></li>
      @endforeach
      </ol>
      
      
 <div class="carousel-inner" role="listbox">
      @foreach($banner as $key => $list)
     

        <!-- Slide 1 -->
        <div class="carousel-item {{$key == 0 ? 'active' : '' }}" style="background-image: url(admin-assets/images/banner/{{$list->banner_name}}"></div>

      
      @endforeach
 
    </div>
 
 
 

 
      <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>
      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>

      <div class="homeSliderText">
        <div class="container">
          <!--  id="planT" -->
          <a href="trip_plan.php" class="btn-get-started animated fadeInUp scrollto">Plan Your Travel</a>
           <a href="trending.php" class="btn-get-started animated fadeInUp scrollto fndd" id="planB">Find Tours & Activity</a>
          <div id="textPlan">
            <div class="d-flex justify-content aligns-center">
              <div class="bnLeft">
                <h2 class="txtWhite">The new way to plan your next trip.</h2>
                <p>Create a fully customized day by day itinerary for free.</p>
              </div>
              <div class="bnRight">
                <div class="trip-form">
                  <form>
                    <h2 class="text-center">Itinerary planner</h2>
                    <div class="form-middle mb-3">
                      <div style="position: relative;">
                        <select id="combo-box--1" class="my-combo-box form-control form-group" placeholder="Enter destination (region, or city)">
                          <option selected disabled>Enter destination (region, or city)</option>
                          <option value="AU">Australia</option>
                          <option value="IN">India</option>
                          <option value="AL">Afganistan</option>
                          <option value="DZ">Algeria</option>
                          <option value="AS">American Samoa</option>
                          <option value="AD">Andorra</option>
                          <option value="AO">Angola</option>
                          <option value="AI">Anguilla</option>
                          <option value="AQ">Antarctica</option>
                          <option value="AG">Antigua and Barbuda</option>
                          <option value="AR">Argentina</option>
                          <option value="AM">Armenia</option>
                      </select>
                      <i class="fas fa-question-circle" id="help"></i>
                    </div>
                      <!-- <div style="position: relative;">
                        <input role="combobox" id="" type="text" class="search biginput form-control" autocomplete="off" aria-owns="res" aria-autocomplete="both" placeholder="Enter destination (region, or city)"><i class="fas fa-question-circle" id="help"></i>
                      </div> -->
                      <div class="apF">
                        
                      </div>
                      <!-- <div class="autocomplete-suggestions" id="search-autocomplete"></div> -->
                      <a href="javascript:void(0);" class="addDestination">+ Add destination</a>
                    </div>
                    <div class="d-flex">
                      <div id="reportrange" class="pull-left posRe">
                          <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>&nbsp;
                          <span></span> <b class="caret"></b>
                          <input type="text" class="form-control abs g" placeholder="Start  End" id="reportrange">
                          <i class="fas fa-calendar-alt g" id="reportrange"></i>
                      </div>
                      <div class="travL">
                        <p class="txtL"><span>0</span> Travelers</p>
                        <div class="travlNo">
                            <div>
                              <span class="tb">Adult</span>
                              <span class="bt">
                                <div class="value-button" id="decrease" onclick="decreaseValue()" value="Decrease Value">-</div>
                                  <input type="number" id="number" value="0"/>
                                <div class="value-button" id="increase" onclick="increaseValue()" value="Increase Value">+</div>
                              </span>
                            </div>
                            <div>
                              <span class="tb">Teens</span>
                              <span class="bt">
                                <div class="value-button" id="decrease1" onclick="decreaseValue1()" value="Decrease Value">-</div>
                                  <input type="number" id="number1" value="0" />
                                <div class="value-button" id="increase1" onclick="increaseValue1()" value="Increase Value">+</div>
                              </span>
                            </div>
                            <div>
                              <span class="tb">Kids</span>
                              <span class="bt">
                                <div class="value-button" id="decrease2" onclick="decreaseValue2()" value="Decrease Value">-</div>
                                  <input type="number" id="number2" value="0" />
                                <div class="value-button" id="increase2" onclick="increaseValue2()" value="Increase Value">+</div>
                              </span>
                            </div>
                          <a href="javascript:void(0);" class="addPass">Save</a>
                        </div>
                      </div>
                    </div>
                    <a href="route.php" class="btn btn-success" id="saveTrip">Search Your Trip</a>
                    <!-- <input 
    id="search" 
    type="search" 
    name="search" 
    list="searchSuggestions" 
    autocomplete="on"
/>

<datalist id="searchSuggestions">
    <option label="suggested">Deals</option>
    <option label="suggested">Coats</option>
    <option label="suggested">Jeans</option>
    <option label="suggested">Hats</option>
</datalist>
<a href="javascript:void(0);" id="ff">apend</a>

<div id="data"></div> -->
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End Hero -->



  <!-- video section -->

  <div class="container">
    <div class="section-title text-center">
        <h2>How to video</h2>
    </div>
      <div class="bnb">
    <video controls poster="{{url('')}}/front-assets/assets/img/thumbnail.png">
        <i class="fa fa-youtube-play" aria-hidden="true"></i>
       <source src="{{url('')}}/front-assets/assets/img/morocco.mp4" type="video/mp4">
    </video>
</div>
  </div>

  <main id="main">            

    <div class="container">
      <div class="icon-section">
          <div class="section-title text-center">
            <h2>Why use Triplookey</h2>
          </div>
          <div class="icons-bar text-center form-group">
              <div class="row">
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="thumb-1-wrap align-c">
                      <span class="bbs"></span>
                      <p>
                        <b class="h-label">1.lorem epsum lorem</b>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="thumb-2-wrap align-c">
                      <span class="bbs"></span>
                      <p>
                        <b class="h-label">2.lorem epsum lorem</b>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="thumb-3-wrap align-c">
                      <span class="bbs"></span>
                      <p>
                        <b class="h-label">3.lorem epsum lore</b>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                      </p>
                    </div>
                  </div>
                  <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="thumb-4-wrap align-c">
                      <span class="bbs"></span>
                      <p>
                        <b class="h-label">4.lorem epsum lorem</b>
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. 
                      </p>
                    </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
<!-- End video section -->


   <!-- image section started -->
   <div class="container">
    <div class="image-section">
       <div class="section-title text-center">
        <h2>Things to do</h2>
       </div>
      <div class="row form-group">
        <div class="col-lg-5">
           <div class="image-part">
               <div class="image">
                   <img src="{{url('')}}/front-assets/assets/img/Mask Group 42.png">
                   <div class="image-text">
                       <p>North Morocco adventure</p>
                   </div>
               </div>
           </div>
        </div>
        <div class="col-lg-7">
           <div class="image-part">
               <div class="image">
                   <img src="{{url('')}}/front-assets/assets/img/img2.png">
                   <div class="image-text">
                       <p>North Morocco adventure</p>
                   </div>
               </div>
           </div>
        </div>
        
   </div>
   <div class="row form-group">
       <div class="col-lg-4">
          <div class="image-part">
              <div class="image">
                  <img src="{{url('')}}/front-assets/assets/img/afrrica.png">
                  <div class="image-text">
                      <p>North Morocco adventure</p>
                  </div>
              </div>
          </div>
       </div>
       <div class="col-lg-4">
          <div class="image-part">
              <div class="image">
                  <img src="{{url('')}}/front-assets/assets/img/mauly idris.png">
                  <div class="image-text">
                      <p>North Morocco adventure</p>
                  </div>
              </div>
          </div>
       </div>
       <div class="col-lg-4">
           <div class="image-part">
               <div class="image">
                   <img src="{{url('')}}/front-assets/assets/img/valburis.png">
                   <div class="image-text">
                       <p>North Morocco adventure</p>
                   </div>
               </div>
           </div>
        </div>
        
       
     </div>
     <div class="row form-group">
      <div class="col-lg-7">
         <div class="image-part">
             <div class="image">
                 <img src="{{url('')}}/front-assets/assets/img/Mask Group 47.png">
                 <div class="image-text">
                     <p>North Morocco adventure</p>
                 </div>
             </div>
         </div>
      </div>
      <div class="col-lg-5">
         <div class="image-part">
             <div class="image">
                 <img src="{{url('')}}/front-assets/assets/img/Group 48.png">
                 <div class="image-text">
                     <p>North Morocco adventure</p>
                 </div>
             </div>
         </div>
      </div>
      
 </div>

    </div>
</div>





<!-- imnahjhsajhsjh -->
<!-- logo croisel -->
<section id="clients" class="clients">

    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2>Travelling loking partner</h2>
            <p class="select-hotel"> Select Flight, hotels , homestays and tour form any these top international travel brand in our vacation Planner</p>
        </div>

      <div class="clients-slider swiper mt-4" id="sw">
        <div class="swiper-wrapper align-items-center">
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-1.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-2.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-3.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-4.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-5.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-6.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-7.png" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{url('')}}/front-assets/assets/img/client-8.png" class="img-fluid" alt=""></div>
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>

  </section><!-- End Clients Section -->



<!-- Blog listing section start -->
  <input type="hidden" value="0" id="firstV" class="add">
  <input type="hidden" value="0" id="secondV" class="add">
  <input type="hidden" value="0" id="thirdV" class="add">

  </main>
<style>
  .swiper-slide{padding: 16px;}
</style>
<!--modal login and register --->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!---end coding of modal login or register ---page--->
@endsection