<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>@yield("title")</title>
  <link rel="icon" type="image/x-icon" href="{{url('')}}/front-assets/assets/img/newtriplogo.png" />
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Google Fonts -->
  <link href="{{url('')}}/front-assets/assets/canilari-1/Canilari-Pro.ttf" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="front-assets/assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> -->
  <link href="{{url('')}}/front-assets/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/canilari-1/Canilari-Ornaments.ttf" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="{{url('')}}/front-assets/assets/css/style.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/css/nouislider.css" rel="stylesheet">
  <link href="{{url('')}}/front-assets/assets/css/swiper.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="{{url('')}}/front-assets/assets/css/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
  
<link href="https://cdnjs.cloudflare.com/ajax/libs/air-datepicker/2.2.3/css/datepicker.css">
<link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css">


</head>

<body>

  <!-- ======= Header ======= -->
  <!-- fixed-top  -->
  <header id="header" class="header-inner-pages">
    <div class="container  justify-content-between">

      <!-- <li class="logo"><a href="index.html">Hidayah</a></li>  -->
      <!-- Uncomment below if you prefer to use an image logo -->
      
     
      
      <?php
      if($logo_image!=''){ ?>
         <a href="{{url('/')}}" class="logo mobile"><img src="{{url('admin-assets/images/admin_image').'/'.$logo_image}}" alt="" class="img-fluid"></a> 
     <?php }else{ ?>
          
        <a href="{{url('/')}}" class="logo mobile"><img src="{{url('')}}/front-assets/assets/img/newtriplogo.svg" alt="" class="img-fluid"></a>  
     <?php }
      
      ?>
      
      
      



      <nav id="navbar" class="navbar">
        <ul class="navbar-left text-left">
           <li>
               <?php
      if($logo_image!=''){ ?>
         <a href="{{url('/')}}" class="logo desk"><img src="{{url('admin-assets/images/admin_image').'/'.$logo_image}}" alt="" class="img-fluid"></a> 
     <?php }else{ ?>
          
        <a href="{{url('/')}}" class="logo desk"><img src="{{url('')}}/front-assets/assets/img/newtriplogo.svg" alt="" class="img-fluid"></a>  
     <?php }
      
      ?>
               
               
               </li>
          <li><a class="nav-link scrollto" href="/blog">Things to do</a></li>
          <li><a class="nav-link scrollto" href="/stay">Stays </a></li>
          <li><a class="nav-link scrollto" href="/activity">Activites</a></li>
        </ul>
        <ul class="text-right">
          <li><a class="nav-linkscrollto" href="#">Mad</a></li>
          <li><a><img src="{{url('')}}/front-assets/assets/img/iconstar.png" class="stt"></a></li>
          <li><a class="nav-link scrollto" href="/login">Log In</a></li>
          <!-- <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
          </li> -->
          <li><a class="nav-link scrollto" href="/signup">Sign Up</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle text-right"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->


    @yield("content")





   <!-- ======= Footer ======= -->
  
<footer class="new_footer_area bg_color">
  <div class="new_footer_top mt-5">
      <div class="container">
          <div class="row">
            <div class="col-lg-2 col-md-6">
              <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                  <h3 class="f-title f_600 t_color f_size_18" ><span style="color: #000000;">Triplooky</span></h3>
                  <ul class="list-unstyled f_list">
                      <li><a href="/about">About us</a></li>
                      <li><a href="partner-with-us.php">Partner with us</a></li>
                      <!-- <li><a href="#">Triplooky</a></li> -->
                   
                  </ul>
              </div>
          </div>
              <div class="col-lg-2 col-md-6">
                  <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                      <h3 class="f-title f_600 t_color f_size_18">Browse</h3>
                      <ul class="list-unstyled f_list">
                          <li><a href="recent-trip.php">Trip by Other Users</a></li>
                          <li><a href="top-destination.php">Destination</a></li>
                          <!-- <li><a href="#">Credit</a></li> -->
                       
                  
                      </ul>
                  </div>
              </div>

              <div class="col-lg-2 col-md-6">
                <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInLeft;">
                    <h3 class="f-title f_600 t_color f_size_18">Help</h3>
                    <ul class="list-unstyled f_list">
                        <li><a href="/faq">FAQ</a></li>
                        <li><a href="/contactus">Contact us</a></li>
                        <li><a href="/privacypolicy">Privacy Policy</a></li>
                        <li><a href="/cookiepolicy">Cookie Policy</a></li>
                        <li><a href="/copyright-policy">Copyright Policy</a></li>
                        <li><a href="/term">Terms of Uses</a></li>
                    </ul>
                </div>
              </div>
              <div class="col-lg-3 col-md-6">
                  <div class="f_widget about-widget pl_70 wow fadeInLeft" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInLeft;">
                      <h3 class="f-title f_600 t_color f_size_18 d-flex">Setting</h3>
                      <ul class="list-unstyled f_list d-flex justify-content align-center">
                          <li><a href="#">Currency:Moroccan Dhiram</a></li>
                      
                          <li class="ml-auto"><a href="javascript:void(0)" data-modal-trigger="sample-modal" class="demo__btn demo__btn--secondary"><u>Change</u></a></li>
                    
                      </ul>
                      <ul class="list-unstyled f_list d-flex justify-content align-center">
                        <li><a href="#">Language:English</a></li><br> 
                    
                        <li class="ml-auto"><a href="javascript:(void)" id="open-btn1"><u>Change</u></a></li>
                  
                    </ul>
                      <!-- <ul class="list-unstyled f_list text-right">
                        <li><a href="#">Dhiram</a></li>
                    
                        <li><a href="#">Languag</a></li>
                  
                    </ul> -->
                  </div>
              </div>
              <div class="col-lg-3 col-md-6">
                  <div class="f_widget social-widget pl_70 wow fadeInLeft" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInLeft;">
                      <!-- <h3 class="f-title f_600 t_color f_size_18">Team Solutions</h3> -->
                      <div class="f_social_icon">
                          <a href="#" class="facebook"><i class="fab fa-facebook" aria-hidden="true"></i></a>
                          <a href="#" class="twitter"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                          <a href="#" class="insta"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                          <a href="#" class="youtube"><i class="fab fa-youtube" aria-hidden="true"></i></a>
                      </div>
                      <div class="visit-blog text-center mt-3">
                       <a href="blog.php"> Visit Our Blog<i class="fa fa-angle-double-right" style="margin-left: 3px;" aria-hidden="true"></i></a>
                      </div>
                  </div>
              </div>
          </div>
      </div>
    
  </div>
  <div class="footer_bottom mt-3">
      <div class="container">
          <div class="row align-items-center">
              <div class="col-lg-12 text-center border-2">
                  <p class="mt-3 f_400 blue"><span>© 2021</span> Triplooky <span>
                    <strong> reserved and design by Nota Bene Global Services Pvt Ltd.</strong></span></p>
              </div>
              
          </div>
      </div>
  </div>
</footer><!-- End Footer -->

<!-- modal section -->

<!-- <a href="javascript:void(0)" data-modal-trigger="sample-modal" class="demo__btn demo__btn--secondary">Sample Modal</a> -->


<div class="modal" data-modal-name="sample-modal">
    <div class="modal__dialog">
        <button class="modal__close" data-modal-dismiss>×</button>
     
        <div class="modal__content">
          <div class="modalup text-center">
            <h3 class="chng-cur">
              Change currency
            </h3>
          </div>
          <div class="topcur">
            <h4 class="tpp">top cureenecy</h4>
            <div class="topp d-flex">

              <p class="c1"><b>US$</b> U.S. Dollar</p>
              <p class="c2"><b>£</b> Euro</p>
               <p class="c3"><b>₹</b> Indian Rupee </p>
            
            </div>
          </div>




          <div class="all-currencies">
            <h3 class="fsf">All currencies</h3>
            <div class="row">
              <div class="col-md-3 sm-12">
                <div class="con-cur">
                  <p><span>ARS</span> Argentine Peso</p>
                  <p><span>AUS</span> Australian Dolar </p>
                  <p><span>AZN</span> Azerbaijani Manat</p>
                  <p><span>BHD</span> Bahraini Dinar</p>
                  <p><span>RS</span> Brazillian Real</p>
                  <p><span>BGN</span> Bulgarian Lev</p>
                  <p><span>CAS</span> Canadian Dollar</p>
                  <p><span>XOF</span> CFA Franc BCEAO</p>
                  <p><span>CLS</span> Chilean Peso </p>
                  <p><span>CNY</span> Chinese Yuan</p>
                  <p><span>COP</span> Colombian Peso</p>
                  <p><span>CZK</span> Czech Peso</p>
                  <p><span>DKK</span> Danis Krone</p>
                </div>
              </div>

               <div class="col-md-3 sm-12">
                <div class="con-cur">
                  <p><span>EGP</span> Eyptian Pound</p>
                  <p><span>E</span> Euro</p>
                  <p><span>FJD</span> Fijian Dollar</p>
                  <p><span>GEL</span> Georgian Lari</p>
                  <p><span>HK$</span> Hong Kong Dollar</p>
                  <p><span>HUF</span> Hungarian Forint</p>
                  <p><span>KR</span> Icelandic Krone</p>
                  <p><span>₹</span> Indian Rupee</p>
                  <p><span>IDR</span> Indonesian Rupiee</p>
                  <p><span>₪</span> Israeli New Sheqel</p>
                  <p><span>JPY</span> Japanese Yen</p>
                  <p><span>JPD</span> Jordanian Dinar</p>
                  <p><span>KZD</span> Kazakisthan Ten..</p>
                </div>
              </div>

               <div class="col-md-3 sm-12">
                <div class="con-cur">
                  <p><span>w</span> Korean Won</p>
                  <p><span>KWD</span> Kuwati Dinar</p>
                  <p><span>MYR</span> Malaysia Ringgit</p>
                  <p><span>MXS</span> Mexican Peso </p>
                  <p><span>MDL</span> Moldovan Leu</p>
                  <p><span>NAD</span> Namibian Dollar</p>
                  <p><span>NTS</span> New Taiwan Dollar</p>
                  <p><span>NZD</span> NewZealand Dollar</p>
                  <p><span>NOK</span> Norwegian Krone</p>
                  <p><span>OMR</span> Oman Rial</p>
                  <p><span>PLN</span> Polish Zloty</p>
                  <p><span>£</span> Pound Sterling</p>
                  <p><span>QAR</span> Qatar Rial</p>
                </div>
              </div>

               <div class="col-md-3 sm-12">
                <div class="con-cur">
                  <p><span>RON</span> Romanian Leu</p>
                  <p><span>RUB</span> Russian Ruble</p>
                  <p><span>SAR</span> Saudi Riyal</p>
                  <p><span>S$</span> Singapore Dollar</p>
                  <p><span>ZAR</span> South African Ra..</p>
                  <p><span>SEK</span> Swedish Krona</p>
                  <p><span>CHF</span> Swiss Franc</p>
                  <p><span>THB</span> Thai Baht</p>
                  <p><span>TL</span> Turkish Lira </p>
                  <p><span>AED</span> U.A.E. Dhiram</p>
                  <p><span>US$</span> U.S. Dollar</p>
                  <p><span>UAH</span> Ukrainian Hryvnia</p>
                  
                </div>
              </div>
            </div>
          </div>
        


           
        </div>
      
    </div>
</div>




<!-- second modal -->

  <!-- <a href="javascript:void(0)" id="open-btn1">
    OPEN THE MODAL
  </a> -->

  <!-- Modal Background and Modal -->
  <div id="modal-background1">
    <div id="modal1">
      <span id="close-btn1">&times;</span>
      <div class="chng-lng">
      <p>Change Language</p>
    </div>
    <form>
      
      <select class="form-control form-control-lg">
  <option>English</option>
  <option>Nederlands</option>
  <option>Arabic</option>
</select>
    </form>
   <!--    <div class="lng">
        <a href="">English</a>
        <a href="">Nederlands</a>
        <a href="">Arabic</a>
      </div> -->
   
    </div>
  </div>


<!-- end secodn ,odal -->


<style>
h5{

  font-size: 13px;

 }
  .modal {
  display: none;
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 15px;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.88);
  -webkit-animation-duration: 0.35s;
          animation-duration: 0.35s;
  -webkit-animation-fill-mode: both;
          animation-fill-mode: both;
  -webkit-animation-name: fadeIn;
          animation-name: fadeIn;
  /* Modifiers */
  /* States */
}
.modal__dialog {
  position: relative;
  max-width: 500px;
  padding: 20px;
  margin: auto;
  border-radius: 4px;
  background-color: #fff;
}
.modal__close {
  position: absolute;
  top: 20px;
  right: 20px;
  padding: 0;
  border: none;
  color: #ccc;
  background-color: transparent;
  background-image: none;
}
.modal__close:focus {
  outline: 0;
}
.modal__header {
  border-bottom: 1px solid #e2e2e2;
}
.modal__title {
  margin: 0 0 15px;
}
.modal__content {
  padding: 10px 0;
  font-size: 13px;
  line-height: 1.6;
  color: #555;
}
.modal__footer {
  padding-top: 20px;
  border-top: 1px solid #e2e2e2;
  text-align: right;
}
.modal--fullscreen {
  padding: 5px;
}
.modal--fullscreen .modal__dialog {
  width: 100%;
  max-width: none;
  height: 100%;
  border-radius: 0;
}
.modal.is-modal-active {
  display: flex;
}
/* Animation */
@-webkit-keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}
@keyframes fadeIn {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

.modal__dialog {
    position: relative;
    max-width: 816px;
    padding: 20px;
    width: 100%;
    margin: auto;
    border-radius: 4px;
    background-color: #fff;
}
.con-cur span {
    font-size: 15px;
    font-weight:900;
    color:black
}
h3.fsf {
    font-size: 23px;
    font-weight: 900;
    color: #000000;
}
h3.chng-cur {
    color: #000000;
    font-weight: 600;
}
p.c2 {
    margin-left: 65px;
}
p.c3 {
    margin-left: 65px;
    font-weight: 900;
    color: #000000;
}
.topp b{
  margin: 10px;
    font-size: 17px;
    font-weight: bolder;
    color: #000;
}
h4.tpp {
    color: #000000;
    font-weight: 700;
}
button.modal__close {
    font-weight: 900;
    font-size: 28px;
    color: #000000;
}



/*second moidal css*/

#modal-background1 {
  display: none;
  background-color: rgba(0, 0, 0, 0.2);
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1;
}


.yes, .no {
  border: none;
  padding: 7px 14px;
  font-size: 1rem;
  border-radius: 5px;
}

.yes {
  background-color: #00ff00;
}

.no {
  background-color: #ff0000;
}

#close-btn1 {
float: right;
font-size: 22px;
}

#close-btn1:hover {
  cursor: pointer;
  color: #ff0000;
}
.chng-lng {
    margin-top: 22px;
}

.lng a {
        color: #000;
    margin: 4px;
    font-size: 19px;}
    
.chng-lng {
    font-size: 24px;
    font-weight: 800;
    margin-top: 22px;
}
/*end css*/
</style>
<!-- end modal scetion -->







  <!-- <div id="preloader"></div> -->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center">
     <i class="bi bi-arrow-up-short"></i> </a>

      


    <div class="social-media-container vertical  clearfix"><div class="social-media-icon-container">
      <div class="social-media-icon">
        <a href="" target="_blank" rel="nofollow">
          <i class="fab fa-facebook-f"></i>
        </a>
      </div>
      <span class="social-media-count">6.1K</span>
      <span class="social-media-followers">Followers</span>
    </div><div class="social-media-icon-container">
      <div class="social-media-icon">
        <a href="" target="_blank" rel="nofollow">
          <i class="fab fa-twitter"></i>
        </a>
      </div>
      <span class="social-media-count">9.2K</span>
      <span class="social-media-followers">Followers</span>
    </div><div class="social-media-icon-container">
      <div class="social-media-icon">
        <a href="" target="_blank" rel="nofollow">
          <i class="fab fa-pinterest-p"></i>
        </a>
      </div>
      <span class="social-media-count">5.3M</span>
      <span class="social-media-followers">Followers</span>
    </div><div class="social-media-icon-container">
      <div class="social-media-icon">
        <a href="" target="_blank" rel="nofollow">
          <i class="fab fa-instagram"></i>
        </a>
      </div>
      <span class="social-media-count">11.4K</span>
      <span class="social-media-followers">Followers</span>
    </div></div>
 

  <!-- Vendor JS Files -->
  

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
  <script src="{{asset('front-assets/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
  <script src="{{asset('front-assets/assets/vendor/glightbox/js/glightbox.min.js')}}"></script>
  <script src="{{asset('front-assets/assets/vendor/isotope-layout/isotope.pkgd.min.js')}}"></script>
  <script src="{{asset('front-assets/assets/vendor/php-email-form/validate.js')}}"></script>
  <script src="{{asset('front-assets/assets/vendor/purecounter/purecounter.js')}}"></script>
  <script src="{{asset('front-assets/assets/vendor/swiper/swiper-bundle.min.js')}}"></script>
  <script src="{{asset('front-assets/assets/vendor/waypoints/noframework.waypoints.js')}}"></script>
  <script src="{{asset('front-assets/assets/js/swiper.min.js')}}"></script>
  <script src="{{asset('front-assets/assets/js/mainjs')}}"></script>
  <script src="{{asset('front-assets/assets/js/custome.js?cache=<?php echo time() ?> ')}}"></script>


  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
   <script>
    $(window).scroll(function() {    
      var scroll = $(window).scrollTop();

      if (scroll >= 50) {
          $("#header").addClass("darkHeader");
      } else {
          $("#header").removeClass("darkHeader");
      }
    });
  </script>
  <script>
    $(window).scroll(function() {    
      var scroll = $(window).scrollTop();

      if (scroll >= 100) {
          $(".activityMenu").addClass("top72");
      } else {
          $(".activityMenu").removeClass("top72");
      }
    });
  </script>
  <script>
    $('.collm').click(function(e) {
      e.preventDefault();
    
      var $this = $(this);
    
      if ($this.next().hasClass('show')) {
          $this.next().removeClass('show');
          $this.next().slideUp(350);
      } else {
          $this.parent().parent().find('li .inner').removeClass('show');
          $this.parent().parent().find('li .inner').slideUp(350);
          $this.next().toggleClass('show');
          $this.next().slideToggle(350);
      }
  });
  </script>
  <script>
    const slider = document.getElementById('sliderPrice');
    const rangeMin = parseInt(slider.dataset.min);
    const rangeMax = parseInt(slider.dataset.max);
    const step = parseInt(slider.dataset.step);
    const filterInputs = document.querySelectorAll('input.filter__input');

    noUiSlider.create(slider, {
        start: [rangeMin, rangeMax],
        connect: true,
        step: step,
        range: {
            'min': rangeMin,
            'max': rangeMax
        },
      
        // make numbers whole
        format: {
          to: value => value,
          from: value => value
        }
    });

    // bind inputs with noUiSlider 
    slider.noUiSlider.on('update', (values, handle) => { 
      filterInputs[handle].value = values[handle]; 
    });

    filterInputs.forEach((input, indexInput) => { 
      input.addEventListener('change', () => {
        slider.noUiSlider.setHandle(indexInput, input.value);
      })
    });
  </script>
  <script>
    $('.tb').click(function() {
      $(this).addClass('active').siblings().removeClass('active');
    });
  </script>
 
  <script>
    $('.modal-close').click(function(){
      $('.modal-window').css('visibility', 'hidden');
    })
  </script>
  <script>
    $('.modal-window').css('visibility', 'hidden');
    $('.replybtn').click(function(){
      $('.modal-window').css('visibility', 'visible');
    })
  </script>
  <script>
    $('.gridV').click(function(){
      $(this).hide();
      $('.listV').show();
      $('#viewListing').hide();
      $('#viewGrid').show();
    });

    $('.listV').click(function(){
      $(this).hide();
      $('.gridV').show();
      $('#viewListing').show();
      $('#viewGrid').hide();
    });
  </script>
  <script>
    //-----JS for Price Range slider-----

$(function() {
  $( "#slider-range" ).slider({
    range: true,
    min: 1,
    max: 36100,
    values: [ 1, 36100 ],
    slide: function( event, ui ) {
    $( "#amount" ).val( "MAD" + ui.values[ 0 ] + " - MAD" + ui.values[ 1 ]);
    }
  });
  $( "#amount" ).val( "MAD" + $( "#slider-range" ).slider( "values", 0 ) +
    " - MAD" + $( "#slider-range" ).slider( "values", 1 ) + '+' );
});
  </script>
  <script>
    // INCLUDE JQUERY & JQUERY UI 1.12.1
    $( function() {
      $( "#datepicker" ).datepicker({
        dateFormat: "dd-mm-yy"
        , duration: "fast"
      });
    } );
  </script>

<script>
    $('.faq-heading').click(function () {
  
    $(this).parent('li').toggleClass('the-active').find('.faq-text').slideToggle();
});
</script>
<script>
  
$(function() {

    var start = moment().subtract(5, 'days');
    var end = moment();

    function cb(start, end) {
      $('#reportrange span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
      
    }

    $('#reportrange').daterangepicker({
         // opens: 'left',
        startDate: start,
        endDate: end
    }, cb);

    cb(start, end);
    
});
</script>
<!-- <script>
  
$(function() {
  $('#reportrange, #reportrange span').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});
</script> -->
<script>
  $('.g').click(function() {
     $('.g').hide();
  });
</script>
<script>
  var _targettedModal,
    _triggers = document.querySelectorAll('[data-modal-trigger]'),
    _dismiss = document.querySelectorAll('[data-modal-dismiss]'),
    modalActiveClass = "is-modal-active";

function showModal(el){
    _targettedModal = document.querySelector('[data-modal-name="'+ el + '"]');
    _targettedModal.classList.add(modalActiveClass);
}

function hideModal(event){
    if(event === undefined || event.target.hasAttribute('data-modal-dismiss')) {
        _targettedModal.classList.remove(modalActiveClass);
    }
}

function bindEvents(el, callback){
    for (i = 0; i < el.length; i++) {
        (function(i) {
            el[i].addEventListener('click', function(event) {
                callback(this, event);
            });
        })(i);
    }   
}

function triggerModal(){
    bindEvents(_triggers, function(that){
        showModal(that.dataset.modalTrigger);
    });
}

function dismissModal(){
    bindEvents(_dismiss, function(that){
        hideModal(event);
    });
}

function initModal(){
    triggerModal();
    dismissModal();
}

initModal();

</script>

<script>
  

  // select the open-btn button
let openBtn1 = document.getElementById('open-btn1');
// select the modal-background
let modalBackground1 = document.getElementById('modal-background1');
// select the close-btn 
let closeBtn1 = document.getElementById('close-btn1');

// shows the modal when the user clicks open-btn
openBtn1.addEventListener('click', function() {
  modalBackground1.style.display = 'block';
});

// hides the modal when the user clicks close-btn
closeBtn1.addEventListener('click', function() {
  modalBackground1.style.display = 'none';
});

// hides the modal when the user clicks outside the modal
window.addEventListener('click', function(event) {
  // check if the event happened on the modal-background
  if (event.target === modalBackground1) {
    // hides the modal
    modalBackground1.style.display = 'none';
  }
});
</script>
  <script>
 

 




$(document).ready(function() {

  $('#example-1').progress_fnc();
  $('#example-2').progress_fnc();
  $('#example-3').progress_fnc();
  $('#example-4').progress_fnc();
  $('#example-5').progress_fnc();
  $('#example-6').progress_fnc();
  $('#example-7').progress_fnc();
  $('#example-8').progress_fnc();
  $('#example-9').progress_fnc();
  $('#example-10').progress_fnc();
  $('#example-11').progress_fnc();
  $('#example-12').progress_fnc();
  $('#example-13').progress_fnc();

  $('.progressStart').on('click', function() {
    var perent = $(this).closest("div").attr("id");
    $('#' + perent).progress_fnc({ type: 'start' });
  });

  $('.progressReset').on('click', function() {
    var perent = $(this).closest("div").attr("id");
    $('#' + perent).progress_fnc({ type: 'reset' });
  });

});


(function($) {

  $.fn.progress_fnc = function(options) {
    var settings = $.extend({
      type: 'start'
    }, options);

    var div = $(this);
    var progress = div.find('.cssProgress');

    progress.each(function() {
      var self = $(this);
      var progress_bar = self.find('.cssProgress-bar');
      var progress_label = self.find('.cssProgress-label, .cssProgress-label2');
      var progress_value = progress_bar.data('percent');
      var percentage = parseInt(progress_value, 10);

      progress_bar.css({'width': '0%', 'transition': 'none', '-webkit-transition': 'none', '-moz-transition': 'none'});

      if(settings.type == 'start') {

        progress_bar.animate({
          width: percentage
        }, {
          duration: 1000,
          step: function(x) {
            progress_label.text(Math.round(x));
          }
        });

      } else if(settings.type == 'reset') {
        progress_bar.css('width', '0%');
        progress_label.text('0%');
      }

    });
  }

}(jQuery));
</script>

<script>
   $(document).ready(function() {
// Swiper: Slider
    new Swiper('#sw', {
        loop: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        slidesPerView: 7,
        paginationClickable: false,
        spaceBetween: 16,
        breakpoints: {
            1920: {
                slidesPerView: 7,
                spaceBetween: 16
            },
            1028: {
                slidesPerView: 4,
                spaceBetween: 12
            },
            480: {
                slidesPerView: 2,
                spaceBetween: 6
            }
        }
    });
});
</script>
<script>
  $('#planT').click(function(){
    $(this).hide();
    $('#textPlan').show();
  });
</script>
<!-- <script>
    $('#ff').click(function(i, e) {
      i = 0;
      i <= 10;
      i++ ;

        $('#data').append('<input id="search" class="tt" type="search" name="search" list="" autocomplete="on"/><datalist id="" class="dd"><option label="suggested">Casablanca</option><option label="suggested">Fez</option><option label="suggested">Tangier</option><option label="suggested">Marrakesh</option></datalist>');
        $(".tt").attr("list", "searchSuggestions_" + i);
        $(".dd").attr("id", "searchSuggestions_" + i);
      
    });
</script> -->
<script>
  $(document).ready(function() {
  var suburbs = ["Aberfeldy Township", "Altona", "Arthurs Creek", "Arthurs Seat", "Ashwood", "Bacchus Marsh Werribee River", "Ballan", "Beaconsfield Upper", "Beenak", "Berwick", "Blackburn", "Blackburn North", "Blue Mountain", "Box Hill", "Braeside", "Braeside Park", "Broadmeadows", "Brooklyn", "Bulla", "Bulla North", "Bulleen", "Bundoora", "Burnley", "Burwood East", "Cambarville", "Cardinia", "Caulfield", "Caulfield North", "Cement Creek", "Christmas Hills", "Clarkefield", "Clarkefield", "Clayton", "Clearwater Aqueduct", "Coburg", "Coldstream", "Collingwood", "Craigieburn", "Craigieburn East", "Cranbourne", "Dandenong", "Dandenong South", "Dandenong West", "Darraweit", "Deer Park", "Devilbend Reservoir", "Diggers Rest", "Dixons Creek", "Doncaster", "Doncaster East", "Drouin West", "Durdidwarrah", "Eastern G.C. Doncaster", "Elsternwick", "Eltham", "Emerald", "Epping", "Essendon", "Fairfield", "Fawkner", "Fiskville", "Flemington", "Footscray", "Frankston North", "Frankston Pier", "Gardiner", "Glen Forbes South", "Glen Waverley", "Graceburn", "Graceburn Creek Aqueduct", "Greensborough", "Greenvale Reservoir", "Groom's Hill", "Hampton", "Hampton Park", "Hawthorn", "Headworks", "Healesville", "Heathmont", "Heidelberg", "Hurstbridge", "Iona", "Ivanhoe", "Kangaroo Ground", "Keilor", "Keilor North", "Kew", "Keysborough", "Kinglake", "Knox", "Konagaderra", "Kooweerup", "Lake Borrie", "Lancefield", "Lancefield North", "Launching Place", "Lilydale Lake", "Little River", "Loch", "Longwarry North", "Lower Plenty", "Lyndhurst", "Lysterfield", "Maribyrnong", "Maroondah Reservoir", "Melton Reservoir", "Melton Sth Toolern Creek", "Mentone", "Mernda", "Millgrove", "Mitcham", "Montrose", "Mooroolbark", "Mornington", "Mount Dandenong", "Mount Evelyn", "Mount View", "Mt Blackwood", "Mt Bullengarook", "Mt Donna Buang", "Mt Evelyn Stringybark Creek", "Mt Gregory", "Mt Hope", "Mt Horsfall", "Mt Juliet", "Mt Macedon", "Mt St Gwinear", "Mt St Leonard", "Mt Waverley", "Myrrhee", "Narre Warren North", "Nayook", "Neerim South", "Neerim-Elton Rd", "Neerim-Neerim Creek", "Neerim-Tarago East Branch", "Neerim-Tarago West Branch", "North Wharf", "Northcote", "Notting Hill", "Nutfield", "O'Shannassy Reservoir", "Oakleigh South", "Officer", "Officer South", "Olinda", "Pakenham", "Pakenham East", "Pakenham West", "Parwon Parwan Creek", "Poley Tower", "Preston", "Reservoir", "Ringwood", "Rockbank", "Romsey", "Rosslynne Reservoir", "Rowville", "Sandringham", "Scoresby", "Seaford", "Seaford North", "Seville East", "Silvan", "Smiths Gully", "Somerton", "Southbank", "Spotswood", "Springvale", "St Albans", "St Kilda Marina", "Sunbury", "Sunshine", "Surrey Hills", "Tarago Reservoir", "Tarrawarra", "Templestowe", "The Basin", "Thomson Dam", "Tonimbuk", "Toolern Vale", "Torourrong Reservoir", "U/S Goodman Creek Lerderderg River", "Upper Lang Lang", "Upper Pakenham", "Upper Yarra Dam", "Wallaby Creek", "Wallan", "Wantirna South", "Warrandyte", "Williamstown", "Woori Yallock", "Woori Yallock Creek", "Wyndham Vale", "Yallock outflow Cora Lyn", "Yannathan", "Yarra Glen", "Yarra Glen Steels Creek", "Yarra Junction", "Yarra River downstream Doctors Creek", "Yellingbo", "Yering"];
  var cache = {};
  var searchedBefore = false;
  var counter = 1;
  var highligtCounter = 0;
  var keys = {
    ESC: 27,
    TAB: 9,
    RETURN: 13,
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40
  };
  $(".search").on("input", function(event) {
    doSearch(suburbs);
  });

  $(".search").on("keydown", function(event) {
    doKeypress(keys, event);
  });
  });

  function doSearch(suburbs) {
    var query = $(".search").val();
    $(".search").removeAttr("aria-activedescendant");
    //$('#hint').val('');

    if ($(".search").val().length >= 2) {

      //Case insensitive search and return matches to build the  array
      var results = $.grep(suburbs, function(item) {
        return item.search(RegExp("^" + query, "i")) != -1;

      });

      if (results.length >= 1) {
        $("#res").remove();
        $('#announce').empty();
        $(".autocomplete-suggestions").show();
        $(".autocomplete-suggestions").append('<div id="res" role="listbox" tabindex="-1"></div>');
        counter = 1;
      }

      //Bind click event to list elements in results
      $("#res").on("click", "div", function() {
        $(".search").val($(this).text());
        $("#res").remove();
        $('#announce').empty();
        $(".autocomplete-suggestions").hide();
        counter = 1;

      });

      //Add results to the list
      for (term in results) {

        if (counter <= 5) {
          $("#res").append("<div role='option' tabindex='-1' class='autocomplete-suggestion py-3' id='suggestion-" + counter + "'>" + results[term] + "</div>");
          counter = counter + 1;
        }

      }
      var number = $("#res").children('[role="option"]').length
      if (number >= 1) {
        $("#announce").text(+number + " suggestions found" + ", to navigate use up and down arrows");
      }

    } else {
      $("#res").remove()
      $('#announce').empty();
      $(".autocomplete-suggestions").hide();
    }

  }

  function doKeypress(keys, event) {
    var highligted = false;
    highligted = $('#res').children('div').hasClass('highligt');
    switch (event.which) {

      case keys.ESC:
        $(".search").removeAttr("aria-activedescendant");
        //$('#hint').val('');
        $("#res").remove();
        $('#announce').empty();
        $(".autocomplete-suggestions").hide();
        break;

      case keys.RIGHT:

        return selectOption(highligted)
        break;

      case keys.TAB:
        $(".search").removeAttr("aria-activedescendant");
        //$('#hint').val('');
        $("#res").remove();
        $('#announce').empty();
        $(".autocomplete-suggestions").hide();
        break;

      case keys.RETURN:
        if (highligted) {
          event.preventDefault();
          event.stopPropagation();
          return selectOption(highligted)
        }

      case keys.UP:
        event.preventDefault();
        event.stopPropagation();
        return moveUp(highligted);
        break;

      case keys.DOWN:
        event.preventDefault();
        event.stopPropagation();

        return moveDown(highligted);
        break;

      default:
        return;
    }
  }

  function moveUp(highligted) {
    var current;
    $(".search").removeAttr("aria-activedescendant");
    //$('#hint').val('');
    if (highligted) {
      console.log("Highlighted - " + highligted + "");
      current = $('.highligt');
      current.attr('aria-selected', false);
      current.removeClass('highligt').prev('div').addClass('highligt');
      current.prev('div').attr('aria-selected', true);
      $(".search").attr("aria-activedescendant", current.prev('div').attr('id'));
      //$('#hint').val($('.highligt').text());
      highligted = false;
    } else {

      //Go back to the bottom of the list

      current = $("#res").children().last('div');
      current.addClass('highligt');
      current.attr('aria-selected', true);
      $(".search").attr("aria-activedescendant", current.attr('id'));
      //$('#hint').val($('.highligt').text());

    }
  }

  function moveDown(highligted) {

    var current;
    $(".search").removeAttr("aria-activedescendant");
    //$('#hint').val('');
    if (highligted) {
      console.log("Highlighted - " + highligted + "");
      current = $('.highligt');
      current.attr('aria-selected', false);
      current.removeClass('highligt').next('div').addClass('highligt');
      current.next('div').attr('aria-selected', true);
      $(".search").attr("aria-activedescendant", current.next('div').attr('id'));
      //$('#hint').val($('.highligt').text());
      highligted = false;
    } else {

      //Go back to the top of the list
      current = $("#res").children().first('div');
      current.addClass('highligt');
      current.attr('aria-selected', true);
      $(".search").attr("aria-activedescendant", current.attr('id'));
      //$('#hint').val($('.highligt').text());

    }
  }

  function selectOption(highligted) {
    if (highligted) {
      $(".search").removeAttr("aria-activedescendant");
      //$('#hint').val('');
      $('.search').val($('.highligt').text());
      $('.search').focus();
      $("#res").remove();
      $('#announce').empty();
      $(".autocomplete-suggestions").hide();
    } else {
      return;
    }
  }
</script>
<script>
  $('.addDestination').click(function() {
    $(".apF").append('<div style="position: relative;"><select id="combo-box--1" class="my-combo-box form-control form-group"><option selected disabled>Enter destination (region, or city)</option><option value="AU">Australia</option><option value="IN">India</option><option value="AL">Afganistan</option><option value="DZ">Algeria</option><option value="AS">American Samoa</option><option value="AD">Andorra</option><option value="AO">Angola</option><option value="AI">Anguilla</option><option value="AQ">Antarctica</option><option value="AG">Antigua and Barbuda</option><option value="AR">Argentina</option><option value="AM">Armenia</option></select><i class="fas fa-question-circle" id="help"></i></div>');
  })
  
</script>
<script>
  function increaseValue() {
    var value = parseInt(document.getElementById('number').value, 10);
    var hidValue = parseInt(document.getElementById('firstV').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue++;
    document.getElementById('number').value = value;
    document.getElementById('firstV').value = hidValue;
  }

  function decreaseValue() {
    var value = parseInt(document.getElementById('number').value, 10);
    value = isNaN(value) ? 0 : value;
    var hidValue = parseInt(document.getElementById('firstV').value, 10);
    value < 1 ? value = 1 : '';
    value--;

    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue--;
    document.getElementById('number').value = value;
    document.getElementById('firstV').value = value;
  }
  // 
  function increaseValue1() {
    var value = parseInt(document.getElementById('number1').value, 10);
    var hidValue = parseInt(document.getElementById('secondV').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;

    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue++;
    document.getElementById('number1').value = value;
    document.getElementById('secondV').value = value;
  }

  function decreaseValue1() {
    var value = parseInt(document.getElementById('number1').value, 10);
    var hidValue = parseInt(document.getElementById('secondV').value, 10);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;

    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue--;
    document.getElementById('number1').value = value;
    document.getElementById('secondV').value = value;
  }
  // 
  function increaseValue2() {
    var value = parseInt(document.getElementById('number2').value, 10);
    var hidValue = parseInt(document.getElementById('thirdV').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;

    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue++;
    document.getElementById('number2').value = value;
    document.getElementById('thirdV').value = value;
  }

  function decreaseValue2() {
    var value = parseInt(document.getElementById('number2').value, 10);
    var hidValue = parseInt(document.getElementById('thirdV').value, 10);
    value = isNaN(value) ? 0 : value;
    value < 1 ? value = 1 : '';
    value--;


    hidValue = isNaN(hidValue) ? 0 : hidValue;
    hidValue--;
    document.getElementById('number2').value = value;
    document.getElementById('thirdV').value = value;
  }

</script>
<script>
  $('.txtL').click(function(){
    $('.travlNo').toggleClass('show');
  });
  // 


$('.addPass').click( function(){
  
  var a_value = $('#firstV').val();
  var b_value = $('#secondV').val();
  var c_value = $('#thirdV').val();
  
  $('.txtL span').text(parseInt(a_value) + parseInt(b_value)+ parseInt(c_value));
  $('.travlNo').removeClass('show');
});

  
</script>
<script>
 
$(document).ready(function(){
  $("#planT").click(function(){
    $("#planB").hide();
  });
});

</script>


</body>

</html>
