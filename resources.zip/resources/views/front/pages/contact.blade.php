@extends("front.layout.header")
@section("title","Contact us")
@section("content")
<main id="main">  
   <div id="banner">
      <div class="container">
         <h2>Contact us</h2>
         <ul>
            <li>
               <a href="index.php" class="brdtitle">Home</a>
            </li>
            <li class="list">
             Contact us
            </li>
         </ul>
      </div>
   </div>
   <!-- Blog listing section start -->
   <div class="container mt-5 mb-5">
      <div class="mapouter">
            <div class="gmap_canvas">
               <iframe width="100%" height="250" id="gmap_canvas" src="https://maps.google.com/maps?q=Blu%20Vard%20Area,%20Main%20Double%20Road,%20Africa&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
               <style>.mapouter{position:relative;text-align:right;height:250px;width:100%;}</style>
               <style>.gmap_canvas {overflow:hidden;background:none!important;height:250px;width:100%;}</style>
            </div>
         </div>
          @if(count($data)>0)
          <div class="d-flex just mt-3">
         <div class="contact-social">
            <i class="fas fa-envelope"></i>
            <span>{{$data[0]->email}}</span>
         </div>
         <div class="contact-social">
            <i class="fas fa-phone"></i>
            <span>{{$data[0]->phone}}</span>
         </div>
         <div class="contact-social">
            <i class="fas fa-map-marker-alt"></i>
            <span>{!!$data[0]->address !!}</span>
         </div>
      </div>
          @else
          
          @endif

      <div class="contact-form mt-5">
         <h3>Send us message</h3>
         <form  class="form text-left">
            <div class="row">
               <div class="col-md-4 col-xs-12">
                  <div class="form-group cont">            
                     <input type="text" id="user" class="form-control" placeholder="Your name">
                  </div>
                  <div class="form-group cont">            
                     <input type="email" id="user" class="form-control" placeholder="Your email">
                  </div>
                  <div class="form-group cont">            
                     <input type="text" id="user" class="form-control" placeholder="Your subject">
                  </div>
               </div>
               <div class="col-md-8 col-xs-12">
                  <div class="form-group cont">
                     <textarea cols="6" rows="4" class="form-control" placeholder="Your message"></textarea>
                  </div>
                  <div class="text-right">
                     <button type="submit" class="form-submit">Submit</button>
                  </div>
               </div>
            </div>
         </form>
      </div>
      
   </div>
   
  
  
</main>
@endsection