
<!-- ================================
       START DASHBOARD NAV
================================= -->
<div class="sidebar-nav sidebar--nav">
    <div class="sidebar-nav-body">
        <div class="side-menu-close">
            <i class="la la-times"></i>
        </div><!-- end menu-toggler -->
        <div class="author-content">
            <div class="d-flex align-items-center">
                <div class="author-img avatar-sm">
                    <img src="{{url('')}}/admin-asstes/images/team9.jpg" alt="testimonial image">
                </div>
                <div class="author-bio">
                    <h4 class="author__title p-font">Royel travel agency</h4>
                    <span class="author__meta p-font">Welcome to Admin Panel</span>
                </div>
            </div>
        </div>
        <div class="sidebar-menu-wrap">
            <ul class="sidebar-menu toggle-menu list-items">
                <li class="page-active"><a href="/admin/index"><i class="la la-dashboard mr-2"></i>Dashboard</a></li>
               
                <li><a href="/admin/language"><i class="las la-language mr-2 text-color"></i>Language</a></li>
                <li><a href="/admin/currency"><i class="las la-pound-sign mr-2 text-color"></i>Currency</a></li>
                <li><a href="customer.php"><i class="las la-user-tie mr-2 text-color"></i>Customer</a></li>
               
            
                  <li>
                    <span class="side-menu-icon toggle-menu-icon">
                        <i class="la la-angle-down"></i>
                    </span>
                    <a href="javascript:void(0);"><i class="la la-users mr-2 text-color-3"></i>Activity</a>
                    <ul class="toggle-drop-menu">
                        <li><a href="/admin/add-activity">Add Activity</a></li>
                        <li><a href="/admin/view-activity">View All Activity</a></li>
                       
                    </ul>
                </li>
                
                
                <li>
                    <span class="side-menu-icon toggle-menu-icon">
                        <i class="la la-angle-down"></i>
                    </span>
                    <a href="javascript:void(0);"><i class="la la-users mr-2 text-color-3"></i>Cms</a>
                    <ul class="toggle-drop-menu">
                        <li><a href=javascript:void(0) data-toggle="collapse" data-target="#about" >About us<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="about" style="border-bottom: 3px groove orange;">
                              <a href="/admin/about" class="text-white">Create About us</a>
                              <a href="/admin/about-us-show" class="text-white">View About us</a>
                               
                                
                            </div>

                        </li>
                        <li><a href=javascript:void(0) data-toggle="collapse" data-target="#faq" >FAQ<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="faq" style="border-bottom: 3px groove orange;">
                              <a href="/admin/faq" class="text-white">Create FAQ`s</a>
                              <a href="/admin/faq-show" class="text-white">View FAQ`s</a>
                               
                                
                            </div>

                        </li>
                        <li><a href=javascript:void(0) data-toggle="collapse" data-target="#contact" >Contact us<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="contact" style="border-bottom: 3px groove orange;">
                              <a href="/admin/contact" class="text-white">Create Contact us</a>
                              <a href="/admin/view-contact-us" class="text-white">View Contact us</a>
                               
                                
                            </div>

                        </li>
                      <li><a href=javascript:void(0) data-toggle="collapse" data-target="#policy" >Policy<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="policy" style="border-bottom: 3px groove orange;">
                              <a href="/admin/policy" class="text-white">Create Policy</a>
                              <a href="/admin/view-policy" class="text-white">View Contact us</a>
                               
                                
                            </div>

                        </li>
                       <li><a href=javascript:void(0) data-toggle="collapse" data-target="#cookie-policy" >Cookie Policy<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="cookie-policy" style="border-bottom: 3px groove orange;">
                              <a href="/admin/cookie-policy" class="text-white">Create Cookie policy</a>
                              <a href="/admin/view-cookie-policy" class="text-white">View cookie policy</a>
                               
                                
                            </div>

                        </li>
                        <li><a href=javascript:void(0) data-toggle="collapse" data-target="#copyright-policy" >CopyRight policy<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="copyright-policy" style="border-bottom: 3px groove orange;">
                              <a href="/admin/copy-right" class="text-white">Create CopyRight Policy</a>
                              <a href="/admin/view-copy-right" class="text-white">View CopyRight Policy</a>
                               
                                
                            </div>

                        </li>
                       <li><a href=javascript:void(0) data-toggle="collapse" data-target="#Terms" >Terms and use<i class="la la-angle-down float-right "></i></a>
                            <div class="collapse bg-info" id="Terms" style="border-bottom: 3px groove orange;">
                              <a href="/admin/terms" class="text-white">Create Terms</a>
                              <a href="/admin/view-terms" class="text-white">View Terms</a>
                               
                                
                            </div>

                        </li>
                    </ul>
                </li>
               <!--  <li>
                    <span class="side-menu-icon toggle-menu-icon">
                        <i class="la la-angle-down"></i>
                    </span>
                    <a href="#"><i class="la la-area-chart mr-2 text-color-8"></i>Finance</a>
                    <ul class="toggle-drop-menu">
                        <li><a href="admin-invoice.html">Invoice</a></li>
                        <li><a href="admin-payments.html">Payments</a></li>
                        <li><a href="admin-currency-list.html">Currency List</a></li>
                        <li><a href="admin-dashboard-subscribers.html">Subscribers</a></li>
                    </ul>
                </li> -->
                <li><a href="/admin/banner"><i class="la la-cog mr-2 text-color-10"></i>Slider Settings</a></li>
                <li><a href="{{ url('admin/settings') }}"><i class="la la-cog mr-2 text-color-10"></i>Settings</a></li>
                <li><a href="/admin/logout"><i class="la la-power-off mr-2 text-color-11"></i>Logout</a></li>
            </ul>
        </div><!-- end sidebar-menu-wrap -->
    </div>
</div><!-- end sidebar-nav -->
<!-- ================================
       END DASHBOARD NAV
================================= -->
