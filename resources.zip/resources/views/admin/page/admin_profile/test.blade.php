<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
	<form action="/admin/profile-data" method="post" enctype="mutipart/form-data">
                                        
                                    @csrf
                                         <div class="row">
                                            <input type="file" name="banner">
                                             </div>
                                         </div>
                                             
                                         </div>
                                        
                                       
                                       
                                        <button class="btn-custom">Create Profile</button>
                                     </form>

</body>
</html>