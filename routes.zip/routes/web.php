<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::match(['get','post'],"AdminController\AdminController@test");
Route::get("/","Front\FrontController@index");
//Admin login
Route::get('/admin/login', function () {
    return view('admin.login');
});
Route::match(['get','post'],"/admin/profile-data","AdminController\AdminController@create");

Route::match(['get','post'],"/admin/login-data","AdminController\AdminController@login_data");

Route::match(['get','post'],"/admin/logout","AdminController\AdminController@logout");

Route::match(['get','post'],"/admin/settings","AdminController\AdminController@settings");

Route::match(['get','post'],"/admin/edit_admin_profile/{id}","AdminController\AdminController@edit_admin_profile");

Route::match(['get','post'],"/admin/edit_admin_email/{id}","AdminController\AdminController@edit_admin_email");
Route::match(['get','post'],"/admin/change_admin_password/{id}","AdminController\AdminController@change_admin_password");




//end amdin login

Route::group(['middleware'=>"admin"],function(){
    //admin profile
     Route::match(['get','post'],"/admin/profile","AdminController\AdminController@profile");
    //end admin profiles
    Route::get("/admin/index","AdminController\AdminController@index");
    //banner page routing start
Route::get("/admin/banner","AdminController\BannerController@index");
Route::match(['get','post'],"/admin/banner-create","AdminController\BannerController@create_banner");
Route::match(['get','post'],"/admin/banner-delete","AdminController\BannerController@delete");
Route::match(['get','post'],"/admin/banner-status","AdminController\BannerController@status_change");
Route::match(['get','post'],"/admin/banner-update","AdminController\BannerController@banner_change");


//end coding of banner page routing

//about us page routing start
Route::get("/admin/about","AdminController\AboutUsController@index");
Route::match(['get','post'],"/admin/about-data","AdminController\AboutUsController@create_about");
Route::get("/admin/about-us-show","AdminController\AboutUsController@view_about");
Route::get("/admin/about-edit","AdminController\AboutUsController@update");
Route::match(['get','post'],"/admin/about-update-data","AdminController\AboutUsController@update_data");
Route::get("/admin/about-delete/{id}","AdminController\AboutUsController@delete");
//end coding of about oage


//contact page routing start
Route::get("/admin/contact","AdminController\ContactUsController@index");
Route::match(['get','post'],"/admin/contact-data","AdminController\ContactUsController@create_contact");
Route::get("/admin/view-contact-us","AdminController\ContactUsController@viewContact");
Route::get("/admin/contact-us-edit","AdminController\ContactUsController@update");
Route::match(['get','post'],"//admin/update-contact-data","AdminController\ContactUsController@update_data");
Route::get("/admin/contact-us-delete/{id}","AdminController\ContactUsController@delete");
//end coding of contact page routing

//policy page routing start
Route::get("/admin/cookie-policy","AdminController\CookiePolicyController@index");
Route::match(['get','post'],"/admin/cookie-policy-data","AdminController\CookiePolicyController@create_cookie_policy");
Route::get("/admin/view-cookie-policy","AdminController\CookiePolicyController@view");
Route::get("/admin/cookie-policy-edit","AdminController\CookiePolicyController@update");
Route::match(['get','post'],"/admin/cookie-policy-update-data","AdminController\CookiePolicyController@update_data");
Route::get("/admin/cookie-policy-delete/{id}","AdminController\CookiePolicyController@delete");
//end coding of policy page

//copyright page routing start
Route::get("/admin/copy-right","AdminController\CopyRightController@index");
Route::match(['get','post'],"/admin/copyright-data","AdminController\CopyRightController@create_copyright");
Route::get("/admin/view-copy-right","AdminController\CopyRightController@view");
Route::get("/admin/copy-right-edit","AdminController\CopyRightController@update");
Route::match(['get','post'],"/admin/copyright-update-data","AdminController\CopyRightController@update_data");
Route::get("/admin/copyright-policy-delete/{id}","AdminController\CopyRightController@delete");
//end coding of copyright page routing

//FAQ page routing start
Route::get("/admin/faq","AdminController\FAQController@index");
Route::match(['get','post'],"/admin/faq-data","AdminController\FAQController@create_faq");
Route::get("/admin/faq-show","AdminController\FAQController@view");
Route::get("/admin/faq-edit","AdminController\FAQController@update");
Route::match(['get','post'],"/admin/faq-update-data","AdminController\FAQController@update_data");
Route::get("/admin/faq-delete/{id}","AdminController\FAQController@delete");
//end coding of FAQ page routing

//Term page routing start
Route::get("/admin/terms","AdminController\TermController@index");
Route::match(['get','post'],"/admin/term-data","AdminController\TermController@create_term");
Route::get("/admin/view-terms","AdminController\TermController@view");
Route::get("/admin/terms-edit","AdminController\TermController@update");
Route::match(['get','post'],"/admin/term-update-data","AdminController\TermController@update_data");
Route::get("/admin/terms-delete/{id}","AdminController\TermController@delete");
//end coding of Term page routing

//Privacy Policy page routing coding start
Route::get("/admin/policy","AdminController\PrivacyController@index");
Route::match(['get','post'],"/admin/privacy-data","AdminController\PrivacyController@create");
Route::get("/admin/privacy-policy-edit","AdminController\PrivacyController@update");
Route::get("/admin/view-policy","AdminController\PrivacyController@view");
Route::match(['get','post'],"/admin/privacy-update-data","AdminController\PrivacyController@update_data");
Route::get("/admin/privacy-policy-delete/{id}","AdminController\PrivacyController@delete");

//end coding of privacy page routing

//language page routing
Route::get("/admin/language","AdminController\LanguageController@index");
Route::match(['get','post'],"/admin/create-lang","AdminController\LanguageController@create");
Route::match(['get','post'],"/admin/update-lang","AdminController\LanguageController@update");
Route::match(['get','post'],"/admin/update-status","AdminController\LanguageController@update_status");
Route::match(['get','post'],"/admin/delete-lang","AdminController\LanguageController@delete");




//end language page routing

//currency page routing
Route::get("/admin/currency","AdminController\CurrencyController@index");
Route::match(['get','post'],"/admin/add-currency","AdminController\CurrencyController@create");
Route::match(['get','post'],"/admin/currency-update","AdminController\CurrencyController@update");
Route::match(['get','post'],"/admin/update-status","AdminController\LanguageController@update_status");
Route::match(['get','post'],"/admin/delete-currency","AdminController\CurrencyController@delete");




//end currency page routing



//Activity page routing start
Route::get("/admin/add-activity","AdminController\ActivityController@index");
Route::match(['get','post'],"/admin/activity-data","AdminController\ActivityController@create_activity");
Route::get("/admin/view-activity","AdminController\ActivityController@activity_list");
Route::get("/admin/activity-edit/{id}","AdminController\ActivityController@update_activity");
Route::match(['get','post'],"/admin/activity-update-data","AdminController\ActivityController@update_activity_data");
Route::match(['get','post'],"/admin/delete-activity","AdminController\ActivityController@update_activity_data");

//end coding of Activity page routing

});




//front page routing coding start//
Route::get("/blog","Front\FrontController@blog");
Route::get("/stay","Front\FrontController@stay");
Route::get("/faq","Front\FrontController@faq");
Route::get("/privacypolicy","Front\FrontController@privacy");
Route::get("/cookiepolicy","Front\FrontController@cookie_policy");
Route::get("/contact-us","Front\FrontController@contact_us");
Route::get("/copyright-policy","Front\FrontController@copyright");
Route::get("/term","Front\FrontController@terms");
Route::get("/about","Front\FrontController@about");
Route::get("/contactus","Front\FrontController@contact");
Route::get("/login","Front\FrontController@login");
Route::get("/signup","Front\FrontController@register");
Route::get("/forgotpass","Front\FrontController@forgetpass");
Route::match(['get','post'],"/user-register","Front\UserController@register");
Route::match(['get','post'],"/user-login","Front\UserController@login");
Route::get("/user/logout","Front\UserController@logout");


//end coding of routing front page


//user panel page routing start
Route::group(['middleware'=>"user"],function(){
    Route::get("/user/dashboard","Front\UserController@dashboard");
});
//end coding of use panel page routing